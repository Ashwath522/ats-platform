# High Performance API Service
Built with Python, FastAPI, Redis, and PostgreSQL.